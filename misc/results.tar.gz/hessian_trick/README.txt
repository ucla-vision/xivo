- config.json: the configuration of the estimator for this run.
- tumvi_roomX: the estimated poses of room X in TUM-VI, format [time-stamp, Tx, Ty, Tz, Qx, Qy, Qz, Qw], T stands for translation, Q stands for quaternion
- tumvi_roomX_gt: the ground truth poses of room X in TUM-VI
- tumvi_roomX_bench: benchmark results of room X using the tum_rgbd_benchmark_tools

